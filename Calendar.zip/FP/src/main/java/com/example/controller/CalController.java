package com.example.controller;

import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.domain.CalVO;
import com.example.domain.Criteria;
import com.example.domain.PageMaker;
import com.example.mapper_oracle.CalMapper;

@Controller
public class CalController {
	@Autowired
	CalMapper calMapper;
	
	// 일정 첫page로 연결한다. 
	@RequestMapping("FullCalendar-Example-master/schedule")
	public void schedule(){}
	
	// 일정을 만드는 page로 연결해준다, groub에서도 사용한다. 
	@RequestMapping("schedule_makeSchedule")
	public void schedule_makeSchedule(){	
	}
	
	// 일정을 만들고, 일정 첫page로 연결한다.
	@RequestMapping("makeCal")
	public String makeCal(CalVO vo,HttpSession session){	
		vo.setId((String) session.getAttribute("id"));
		calMapper.makeCal(vo);
		return "schedule_makeSchedule";
	}
	
	@RequestMapping("scheduleList")
	@ResponseBody
	public HashMap<String, Object> scheduleList(String id, int page) {
		HashMap<String, Object> map = new HashMap<>();

		PageMaker pm = new PageMaker();
		Criteria cri = new Criteria();
		cri.setPage(page);
		pm.setCri(cri);
		pm.setTotalCount(calMapper.myschcount(id));

		map.put("pm", pm);
		map.put("callist", calMapper.scheduleList(id));

		return map;
	}
}
