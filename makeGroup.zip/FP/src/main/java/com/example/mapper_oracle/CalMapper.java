package com.example.mapper_oracle;

import com.example.domain.CalVO;

public interface CalMapper {
	public void makeCal(CalVO vo);
}
