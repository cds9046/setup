package com.example.mapper_oracle;

import com.example.domain.CnVO;

public interface CnMapper {
	public void insert(CnVO vo);
}
