package com.example.mapper_oracle;

import com.example.domain.GuVO;

public interface GuMapper {
   public void insert(GuVO gvo);
   
   public Integer max();
}