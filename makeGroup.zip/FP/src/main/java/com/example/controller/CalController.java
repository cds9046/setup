package com.example.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.domain.CalVO;
import com.example.mapper_oracle.CalMapper;

@Controller
public class CalController {
	@Autowired
	CalMapper calMapper;
	
	@RequestMapping("makeCal")
	public String makeCal(CalVO vo,HttpSession session){	
		vo.setId((String) session.getAttribute("id"));
		calMapper.makeCal(vo);
		return "makeSchedule";
	}
}
