package com.example.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.domain.CnVO;
import com.example.mapper_oracle.CnMapper;

@Controller
public class CnController {
   
   @Autowired
   CnMapper mapper;
   
   @RequestMapping("createNotice")
   public void createNotice(){
      
   }
   
   @RequestMapping(value="createNoticeget",method=RequestMethod.POST)
   public String createNoticeget(CnVO vo, HttpSession session){
      vo.setId((String) session.getAttribute("id"));
      if(vo.getCn_bold() == 1){
         vo.setCn_bold(1);
      }else {
         vo.setCn_bold(0);
      }
      vo.setC_code("code");
      System.out.println(vo.toString());
      mapper.insert(vo);
      return "index";
   }
}