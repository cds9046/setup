package com.example.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.domain.CirclesVO;
import com.example.mapper_oracle.CirclesMapper;


@Controller
public class CirclesController {
	@Autowired
	CirclesMapper cMapper;
	
	@Resource(name="uploadPath")
	   String path;
	
	@RequestMapping("makeClub")
	public void signup(){
		
	}
	
	@RequestMapping(value = "makeClubPost", method=RequestMethod.POST)
	public String insert(CirclesVO vo,HttpSession session , HttpServletResponse response){
		String id = (String) session.getAttribute("id");
//		String str = vo.getC_tag();
//	      String[] array = str.split("#");
//	      
//	      //출력            
//	      for(int i=0;i<array.length;i++) {
//	      System.out.println(array[i]);
//	      }
		vo.setC_pid(id);
		cMapper.insert(vo);
		return "index";
	}
	
}
