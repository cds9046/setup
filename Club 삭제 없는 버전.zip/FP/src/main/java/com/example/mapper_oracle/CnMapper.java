package com.example.mapper_oracle;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.example.domain.CnVO;
import com.example.domain.Criteria;

public interface CnMapper {
public void cninsert(CnVO vo);
	
	public void cnupdatepost(CnVO vo);
	
	public CnVO cnread(int cn_no);
	
	public List<CnVO> cnlist(String c_code);
}
