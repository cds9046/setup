package com.example.mapper_oracle;

import java.util.List;

import com.example.domain.ClubVO;
import com.example.domain.Criteria;

public interface ClubMapper {

	public void insert(ClubVO vo);

	public List<ClubVO> myClub(String string);

	public List<ClubVO> cread(Criteria cri);

	public List<ClubVO> getGameList();

	public List<ClubVO> getSportList();

	public List<ClubVO> getStudyList();

	public List<ClubVO> getHobbyList();

	public List<ClubVO> getEtcList();
}
