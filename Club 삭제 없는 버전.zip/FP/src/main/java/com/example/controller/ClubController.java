package com.example.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.domain.ClubVO;
import com.example.domain.CnVO;
import com.example.domain.Criteria;
import com.example.domain.PageMaker;
import com.example.mapper_oracle.ClubMapper;
import com.example.mapper_oracle.CnMapper;


@Controller
public class ClubController {
	@Autowired
	ClubMapper cMapper;
	
	@Autowired
	CnMapper mapper;
	@Resource(name="uploadPath")
	   String path;
	
	// 동아리를 만드는 page로 연결한다.
	@RequestMapping("makeClub")
	public void signup(){
		
	}
	
	// 동아리를 만들어준다.
	@RequestMapping(value = "makeClubPost", method=RequestMethod.POST)
	public String insert(ClubVO vo,HttpSession session , HttpServletResponse response){
		String id = (String) session.getAttribute("id");
//		String str = vo.getC_tag();
//	      String[] array = str.split("#");
//	      
//	      //출력            
//	      for(int i=0;i<array.length;i++) {
//	      System.out.println(array[i]);
//	      }
		vo.setC_pid(id);
		cMapper.insert(vo);
		return "/";
	}
	
	// 선택된 동아리 page로 연결해준다, session값에 c_code를 넣어준다.
	@RequestMapping("club")
	public String club(String c_code, Model model, HttpSession session){
		session.setAttribute("c_code", c_code);
		model.addAttribute("clist", mapper.cnlist(c_code));

		return "club";
	}
	
	// 동아리 main page로 연결한다. 
	@RequestMapping("clubMain")
	public void clubMain(){
	}
	
	// 로그인한 아이디가 회장으로 있는 클럽의 리스트를 가져온다.
	@RequestMapping("myClub")
	@ResponseBody
	public List<ClubVO> myClub(HttpSession session){
		String id = (String) session.getAttribute("id");
		return cMapper.myClub(id);	
	}
	
	// 카테코리별로 추천 동아리 list를 가져온다.
	   @RequestMapping("getGameList")
	   @ResponseBody
	   public List<ClubVO> getGameList(){
	      return cMapper.getGameList();   
	   }
	   @RequestMapping("getSportList")
	   @ResponseBody
	   public List<ClubVO> getSportList(){
	      return cMapper.getSportList();   
	   }
	   @RequestMapping("getStudyList")
	   @ResponseBody
	   public List<ClubVO> getStudyList(){
	      return cMapper.getStudyList();   
	   }
	   @RequestMapping("getHobbyList")
	   @ResponseBody
	   public List<ClubVO> getHobbyList(){
	      return cMapper.getHobbyList();   
	   }
	   @RequestMapping("getEtcList")
	   @ResponseBody
	   public List<ClubVO> getEtcList(){
	      return cMapper.getEtcList();   
	   }
	
}
