package com.example.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.domain.ClubVO;
import com.example.domain.CnVO;
import com.example.domain.Criteria;
import com.example.domain.PageMaker;
import com.example.mapper_oracle.CnMapper;

@Controller
public class CnController {
   
   @Autowired
   CnMapper mapper;
   
   @RequestMapping("cn")
	public String cn(Model model, ClubVO vo) {
		model.addAttribute("clist", mapper.cnlist(vo.getC_code()));
		return "cn";
	}
   
   @RequestMapping("cnRead")
	public void cnRead(int cn_no, Model model) {
		model.addAttribute("vo", mapper.cnread(cn_no));
	}
   
   // 동아리 공지사항 입력 page와 연결시켜준다. 
   @RequestMapping("createNotice")
   public void createNotice(){
      
   }
   
   // 동아리 공지사항을 생성
   @RequestMapping(value="createNotice",method=RequestMethod.POST)
   public String createNoticeget(CnVO vo, HttpSession session){
      vo.setId((String) session.getAttribute("id"));
//      vo.setId((String) session.getAttribute("c_code")); //club에서 session에 c_code를 넣어야 함
      if(vo.getCn_bold() == 1){  // 중요하다는 뜻이 1인가요??
         vo.setCn_bold(1);
      }else {
         vo.setCn_bold(0);
      }
      
      if(vo.getCn_rchk() == null){  // 중요하다는 뜻이 1인가요??
    	  vo.setCn_rchk("nrchk");
      }
      vo.setC_code((String) session.getAttribute("c_code"));
      System.out.println(vo.toString());
      mapper.cninsert(vo);	
      return "club";
   }
   
   @RequestMapping("cnUpdate")
	public void cnUpdate() {

	}

	@RequestMapping(value = "cnUpdatepost", method = RequestMethod.POST)
	public String cnUpdatepost(CnVO vo, HttpSession session) {
		vo.setId((String) session.getAttribute("id"));
		if (vo.getCn_rchk().equals(null)) {
			vo.setCn_rchk("nrchk");
		}

		System.out.println("ㅇㅇㅇㅇㅇ");
		vo.setCn_rchk("nrchk");
		
		vo.setC_code((String) session.getAttribute("c_code"));
		System.out.println(vo.toString());
		mapper.cnupdatepost(vo);
		return "redirect:/";
	}
}