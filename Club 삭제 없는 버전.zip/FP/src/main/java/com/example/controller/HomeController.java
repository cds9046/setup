package com.example.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class HomeController {
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(HttpSession session) {
		
		String dest=(String) session.getAttribute("dest");
	    if(session.getAttribute("dest") !=null){   
	    	session.removeAttribute("dest");
	        return"redirect:" + dest;
	    }
		return "main";
	}
	

	   
	   @RequestMapping("Group")
	   public void Group(){}
   
	   @RequestMapping("Jungmo")
	   public void Jungmo(){}

	   @RequestMapping("FreeBord")
	   public void FreeBord(){}
	   
	   @RequestMapping("Service")
	   public void Service(){}
	   
	   @RequestMapping("Mypage")
	   public void Mypage(){}
	   
	   @RequestMapping("MasterMyPage")
	   public void MasterMyPage(){}
	   
	   @RequestMapping("QnA")
	   public void QnA(){}
	   
	   @RequestMapping("Event")
	   public void Event(){}
	   
	   @RequestMapping("MasterClubManage")
	   public void MasterClubManage(){}
	   
	   @RequestMapping("MasterGroupManage")
	   public void MasterGroupManage(){}
	   
	   @RequestMapping("MyPage")
	   public void MyPage(){}
	   
	   @RequestMapping("UserUpdate")
	   public void UserUpdate(){}

}
