package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.mapper_oracle.CnMapper;



@Service
public class ClubService {
	@Autowired
	CnMapper mapper;
	
	@Transactional
	public void delete(int cn_no){
		mapper.cnrdelete(cn_no);
		mapper.cndelete(cn_no);
	}
}